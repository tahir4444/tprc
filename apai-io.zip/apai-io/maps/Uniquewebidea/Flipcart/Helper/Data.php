<?php
class Uniquewebidea_Flipcart_Helper_Data extends Mage_Core_Helper_Abstract
{
}
	 